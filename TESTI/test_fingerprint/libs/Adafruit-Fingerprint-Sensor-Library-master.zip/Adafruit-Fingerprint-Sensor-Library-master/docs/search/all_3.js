var searchData=
[
  ['deletemodel',['deleteModel',['../class_adafruit___fingerprint.html#a69d8b605f297a71f924dd71b8db075b1',1,'Adafruit_Fingerprint']]]
];
